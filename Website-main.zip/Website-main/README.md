<p align="center">
	<img width="755" height="175" src="assets/images/logo.png">
</p>

# Info
Packet Client is an MCBE Utility mod made by: Packet and Deq
